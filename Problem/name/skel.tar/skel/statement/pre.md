Minta feladat: $\int_0^{\infty} \frac{1}{x^2} dx=$?
